#ifndef DOT_H
#define DOT_H

class dot
{
public:
    dot();
};

#endif // DOT_H
