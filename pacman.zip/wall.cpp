#include "wall.h"
#include <QDebug>
#include "pacman.h"
// wall::wall(short tipo, int width, int height,const QPixmap &pixmap,QObject *parent)
//     :pixmap(pixmap) ,QObject{parent}
// {

//         walltype=tipo;
//         setBrush(Qt::blue);  // Puedes personalizar el color del muro
//         if(walltype==1){
//             rect=new QGraphicsRectItem(18,16 , width, height);
//         }
// }
wall::wall(short tipo, int width, int height,QObject *parent)
    :pixmap(pixmap) ,QObject{parent}
{

    walltype=tipo;
    setBrush(Qt::blue);  // Puedes personalizar el color del muro
    if(walltype==1){
        rect=new QGraphicsRectItem(18,16 , width, height);
    }
}
short wall::getwalltype(){
    return walltype;
}



void wall:: makewalls(QGraphicsScene* scena,pacman* pac){
    QPixmap wall2(":/mapa/pacman/bordes2.png");
    QGraphicsPixmapItem* pixmapItem = new QGraphicsPixmapItem(wall2);
    scena->addItem(pixmapItem);  // Añadir el muro a la escena
    // qDebug()<<"aqui entro"<<Qt::endl;
    if(pac->collidesWithItem(pixmapItem,Qt::IntersectsItemShape)){
        qDebug()<<"colision detectada"<<Qt::endl;
    }else{
        qDebug()<<"no se detecto nada"<<Qt::endl;
    }

}
