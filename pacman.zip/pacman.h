#ifndef PACMAN_H
#define PACMAN_H


#include <QTimer>
#include <QKeyEvent>
#include <QObject>
#include <QGraphicsRectItem>
#include <QPixmap>
#include <QPainter>
class pacman : public QObject,public QGraphicsRectItem//public QGraphicsPixmapItem
{
    Q_OBJECT
public:

    // explicit pacman(const QRectF &rect, const QPixmap &pixmap, QGraphicsRectItem *parent = nullptr);
     explicit pacman(const QRectF &rect, QGraphicsRectItem *parent = nullptr);
    QTimer *timer;
    std::map<int,bool>keys;
    int speed=2;
    void keyPressEvent(QKeyEvent *event);
    void keyReleaseEvent(QKeyEvent *event);
    void paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget) override;

    //nuevo
    void makepac(QGraphicsScene *scena,pacman* pac);
public slots:
     void update();     //actualizar el pacman


private:
    bool mouthOpen;           // Indica si la boca está abierta o cerrada
    QTimer* animationTimer;   // Temporizador para alternar la imagen
    Qt::Key currentDirection; // Dirección actual
    QPixmap pacmanA, pacmanB, pacmanAleft, pacmanBleft;
    QPixmap pacmanAup, pacmanBup, pacmanAdown, pacmanBdown;
    int lastX;
    int lastY;


signals:
};

#endif // PACMAN_H
