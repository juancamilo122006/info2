#ifndef WALL_H
#define WALL_H

#include <QObject>
#include<QGraphicsPixmapItem>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
#include <QBrush>
#include <QPainter>
#include <QPixmap>

class pacman;
class wall : public QObject,public QGraphicsRectItem
{
    Q_OBJECT
public:
    // explicit wall(short tipo, int width, int height, const QPixmap &pixmap,QObject *parent = nullptr);
    explicit wall(short tipo, int width, int height,QObject *parent = nullptr);
    short walltype;
    short getwalltype();
    // void paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget) override;
    void makewalls(QGraphicsScene* scena,pacman* pac);



private:
     QPixmap pixmap;
     QGraphicsRectItem* rect;
signals:
};

#endif // WALL_H
