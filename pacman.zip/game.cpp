#include "game.h"

game::game(QObject *parent)
    : QObject{parent}
{}


void game:: colision(pacman* pac,wall* map){
    if(pac->collidesWithItem(map)){
        qDebug()<<"colision con la pared"<<Qt::endl;
    }


}
