#include "dot.h"

dot::dot() {}
