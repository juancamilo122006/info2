#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include <QGraphicsScene> // Paquete para control de scena
#include <QGraphicsView> // paquete para vistas.
#include <QMainWindow>
#include <QKeyEvent>
#include "pacman.h"
#include "wall.h"
#include"game.h"
QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void keyPressEvent(QKeyEvent *event);
    void keyReleaseEvent(QKeyEvent *event);
    void resizeEvent(QResizeEvent* event);
private:
    Ui::MainWindow *ui;
    QGraphicsView *view;        //estas van a ser las vistas
    QGraphicsScene *scena;         //escenas
    pacman* pac;
};
#endif // MAINWINDOW_H
