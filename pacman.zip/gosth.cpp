#include "gosth.h"
#include <QRandomGenerator>
#include <cmath>
#include <QGraphicsScene>

gosth::gosth(int tipo,pacman* pacmanTarget,const QRectF &rect, QGraphicsItem *parent)
    : QGraphicsRectItem(rect, parent), speedX(0), speedY(0),targetPacman(pacmanTarget) {
    // setBrush(Qt::red); // Puedes cambiar esto por una imagen en paint()
    type=tipo;
    G1=QPixmap(":/gosth/pacman/fantasmaazul.png");
     G3=QPixmap(":/gosth/pacman/fantasmarojo.png");
     G2=QPixmap(":/gosth/pacman/fantasmayellow.png");
      G4=QPixmap(":/gosth/pacman/fantaspink.png");

    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &gosth::move);
    timer->start(100); // Intervalo de movimiento
}

void gosth::setPacmanPosition(const QPointF &pacmanPos) {
    this->pacmanPos = pacmanPos;
}

void gosth::changeDirectionRandomly() {
    speedX = QRandomGenerator::global()->bounded(-1, 2); // -1, 0, 1
    speedY = QRandomGenerator::global()->bounded(-1, 2);
}

void gosth::move() {
    if (QRandomGenerator::global()->bounded(10) < 2) { // Cambiar dirección aleatoriamente a veces
        changeDirectionRandomly();
    }
    // Obtener la posición de Pac-Man
    qreal pacX = targetPacman->x();
    qreal pacY = targetPacman->y();

     qDebug()<<pacX<<" "<<pacY;
    // Posición actual del fantasma
    qreal ghostX = x();
    qreal ghostY = y();

    // qDebug()<<ghostX<<" "<<ghostY;
    // Calcular la dirección hacia Pac-Man
    qreal dx = pacX - ghostX;
    qreal dy = pacY - ghostY;

    qDebug()<<dx<<" "<<dy;
    // Normalizar el vector dirección
    qreal length = std::sqrt(dx * dx + dy * dy);
    if (length > 0) {
        dx /= length; // Dirección normalizada en X
        dy /= length; // Dirección normalizada en Y
    }

    // Ajustar velocidades (multiplicamos por una constante para definir la velocidad deseada)
    speedX = dx*2; // Velocidad en X (ajustar constante según deseado)
    speedY = dy*2; // Velocidad en Y (ajustar constante según deseado)
    // qDebug()<<speedX<<" "<<speedY;
    // Simular el siguiente movimiento
    qreal nextX = ghostX + speedX;
    qreal nextY = ghostY + speedY;
 // qDebug()<<nextX<<" "<<nextY;
    setPos(nextX,nextY );
    // Verificar colisión con el mapa (QGraphicsPixmapItem)
    QList<QGraphicsItem*> collidingItems = scene()->collidingItems(this);
    for (QGraphicsItem* item : collidingItems) {
        if (dynamic_cast<QGraphicsPixmapItem*>(item)) {
            // Si colisiona con el mapa, revertir posición
            setPos(ghostX, ghostY);
            changeDirectionRandomly(); // Cambiar dirección aleatoria
            return;
        }
    }

    // // Si no hay colisión, actualizar posición
     // setPos(nextX, nextY);
}
void gosth::paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget){
    QGraphicsRectItem::paint(painter, option, widget);

    switch (type){
    case 1:{
        painter->drawPixmap(rect().toRect(),G1 );break;
    }
    case 2:{
        painter->drawPixmap(rect().toRect(),G2 );break;
    }
    case 3:{
        painter->drawPixmap(rect().toRect(),G3 );break;
    }
    case 4:{
        painter->drawPixmap(rect().toRect(),G4 );break;
    }
    default:{break;}
    }
}
