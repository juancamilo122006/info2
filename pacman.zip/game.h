#ifndef GAME_H
#define GAME_H

#include <QObject>
#include "pacman.h"
#include "wall.h"
#include <QGraphicsItem>
#include <QDebug>
class game : public QObject
{
    Q_OBJECT
public:
    explicit game(QObject *parent = nullptr);
    static void colision(pacman* pac,wall* map);

signals:
};

#endif // GAME_H
