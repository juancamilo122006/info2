#include "powerpellet.h"
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
powerpellet::powerpellet(const QRectF &rect, QGraphicsRectItem *parent)
    :QGraphicsRectItem(rect, parent) /*QObject{parent}*/
{
    power=QPixmap(":/mapa/pacman/power.png");
    fresas=QPixmap(":/mapa/pacman/fresas.png");



}


// void powerpellet::addscene(QGraphicsScene *scena){
//     int numRows = 47;  // Número de filas (matriz 47x47)
//     int numCols = 47;  // Número de columnas (matriz 47x47)
//     int cellSize = 10; // Tamaño de cada celda en píxeles (10x10)

//     QPixmap mapPixmap(":/mapa/pacman/bordes2.png");  // Crea un objeto QPixmap con la imagen
//     QGraphicsPixmapItem* mapItem = new QGraphicsPixmapItem(mapPixmap);  // Pasa el QPixmap al constructor

//     for (int i = 0; i < numRows; i++) {  // Recorrer filas
//         qDebug()<<"aqui entro";
//         for (int j = 0; j < numCols; j++) {  // Recorrer columnas
//             if (!isWallAt(j, i, mapItem)) {  // Si la celda no está ocupada por un muro
//                 // Crear y colocar la fresa como un QGraphicsRectItem
//                 QRectF rect((i*10)+30,27+(j*10), 15, 15);
//                 powerpellet* fresa=new powerpellet(rect);

//                 scena->addItem(fresa);  // Añadir la fresa a la escena
//             }
//         }
//     }
// }

void powerpellet::addscene(QGraphicsScene *scena) {
    int numRows = 47;  // Número de filas
    int numCols = 47;  // Número de columnas
    int cellSize = 10; // Tamaño de cada celda

    for (int i = 0; i < numRows; i++) {  // Recorrer filas
        for (int j = 0; j < numCols; j++) {  // Recorrer columnas
            if (!isWallAt(j, i, scena)) {  // Si no colisiona con una pared
                // Crear y colocar la fresa como un QGraphicsPixmapItem
                QRectF rect((i*10)+30,27+(j*10), 15, 15);
                powerpellet* fresa=new powerpellet(rect);
                scena->addItem(fresa);  // Agregar la fresa a la escena
            }
        }
    }
}
void powerpellet::paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget) {

    QGraphicsRectItem::paint(painter, option, widget);
    painter->drawPixmap(rect().toRect(),fresas );

}


// bool powerpellet::isWallAt(int cellX, int cellY, QGraphicsPixmapItem* mapItem) {
//     QImage mapImage = mapItem->pixmap().toImage();  // Convertir la imagen del mapa a QImage

//     int cellSize = 10;  // Tamaño de cada celda en píxeles (10x10)

//     // Coordenadas en la imagen
//     int x = cellX * cellSize;
//     int y = cellY * cellSize;

//     // Verificar que las coordenadas estén dentro de los límites de la imagen
//     if (x < 0 || y < 0 || x >= mapImage.width() || y >= mapImage.height()) {
//         return true;  // Considerar fuera de límites como un muro
//     }

//     // Obtener el color del píxel
//     QColor pixelColor = mapImage.pixelColor(x, y);

//     // Si el píxel es negro (paredes) o azul (bordes), considerar que es un muro
//     if (pixelColor == QColor(0, 0, 0) || pixelColor == QColor(0, 0, 253)) {
//         return true;  // Es un muro
//     }

//     return false;  // No es un muro
// }

bool powerpellet::isWallAt(int cellX, int cellY, QGraphicsScene* scena) {
    int cellSize = 15;
    QRectF fresaRect(cellX * cellSize, cellY * cellSize, cellSize, cellSize);
    QGraphicsRectItem* tempFresa = new QGraphicsRectItem(fresaRect);

    scena->addItem(tempFresa);
    QList<QGraphicsItem*> colliding = tempFresa->collidingItems();
    scena->removeItem(tempFresa);
    delete tempFresa;

    for (QGraphicsItem* item : colliding) {
        if (dynamic_cast<QGraphicsPixmapItem*>(item)) {
            qDebug() << "Colisión detectada con pared en celda (" << cellX << "," << cellY << ")";
            return true;
        }
    }
    return false;
}
// bool powerpellet::isPathCenter(int cellX, int cellY, QGraphicsPixmapItem* mapItem) {
//     // Verifica que la celda actual no sea un muro
//     if (isWallAt(cellX, cellY, mapItem)) {
//         return false;
//     }

//     // Verifica vecinos para identificar si es el centro de un camino
//     bool left = !isWallAt(cellX - 15, cellY, mapItem);
//     bool right = !isWallAt(cellX + 15, cellY, mapItem);
//     bool up = !isWallAt(cellX, cellY - 15, mapItem);
//     bool down = !isWallAt(cellX, cellY + 15, mapItem);

//     // Regresa true si la celda es un punto central de un camino (horizontal o vertical)
//     return (left && right && !up && !down) || (!left && !right && up && down);
// }
