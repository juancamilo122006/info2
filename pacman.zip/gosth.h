#ifndef GOSTH_H
#define GOSTH_H

#include <QObject>
#include <QGraphicsRectItem>
#include <QTimer>
#include <QPixmap>
#include <QPainter>
#include "pacman.h"
class gosth : public QObject,public QGraphicsRectItem
{
    Q_OBJECT
public:
    explicit gosth(int tipo,pacman* pacmanTarget,const QRectF &rect, QGraphicsItem *parent = nullptr);
    void setPacmanPosition(const QPointF &pacmanPos); // Para rastrear a Pac-Man
    void changeDirectionRandomly(); // Cambiar dirección de forma aleatoria
    void paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget) override;

public slots:
    void move(); // Mover al fantasma

private:
    QPointF pacmanPos; // Posición de Pac-Man
    qreal speedX, speedY; // Velocidad en X e Y
    QPixmap G1,G2,G3,G4;
    int type;
     pacman* targetPacman;
signals:
};

#endif // GOSTH_H
