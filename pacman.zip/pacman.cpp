#include "pacman.h"
#include <QKeyEvent>
#include <map>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>

pacman::pacman(const QRectF &rect, QGraphicsRectItem *parent)
    : QGraphicsRectItem(rect, parent) //QGraphicsRectItem{parent}    //QGraphicsPixmapItem
{

    pacmanA=QPixmap (":/pacman/pacman/pacA .png");
    pacmanB=QPixmap (":/pacman/pacman/pacB.png");
    pacmanAleft=QPixmap (":/pacman/pacman/pacA left.png");
    pacmanBleft=QPixmap (":/pacman/pacman/pacB left.png");
    pacmanAup=QPixmap (":/pacman/pacman/pacup.png");
    pacmanBup=QPixmap (":/pacman/pacman/pacB up.png");
    pacmanAdown=QPixmap (":/pacman/pacman/pac down.png");
    pacmanBdown=QPixmap (":/pacman/pacman/pacB down.png");
    animationTimer = new QTimer(this);
    this->setFlag(QGraphicsItem::ItemIsFocusable,true);
    this->setFocus();
    keys[Qt::Key_W]=false;
    keys[Qt::Key_A]=false;
    keys[Qt::Key_S]=false;
    keys[ Qt::Key_D]=false;
    timer=new QTimer();
    connect(animationTimer, &QTimer::timeout, this, [this]() {
        mouthOpen = !mouthOpen; // Alternar estado de la boca
        this->QGraphicsItem::update();         // Forzar redibujado
    });
    connect(timer,SIGNAL(timeout()),this,SLOT(update()));
    timer->start(20);
    animationTimer->start(150); // Cambia cada 150 ms
}


void pacman::keyPressEvent(QKeyEvent *event){

    switch (event->key()) {
    case Qt::Key_W:
    case Qt::Key_A:
    case Qt::Key_S:
    case Qt::Key_D:
        keys[event->key()]=true;
        currentDirection = static_cast<Qt::Key>(event->key()); // Guardar dirección actual
    default:
        break;
    }


}


void pacman::update(){
    int speedx=0;
    int speedy=0;
    if(keys[Qt::Key_W]){
        speedy=-speed;
    }else if(keys[Qt::Key_A]){
        speedx=-speed;
    }else if(keys[Qt::Key_S]){
        speedy=speed;
    }else if(keys[ Qt::Key_D]){
        speedx=speed;
    }
    QPointF rectPos=this->pos();
    int move_x=rectPos.x()+speedx;
    int move_y=rectPos.y()+speedy;
    lastX=move_x;
    lastY=move_y;

  this->setPos(move_x,move_y);

  QList<QGraphicsItem*> collidingItems = scene()->collidingItems(this);

  for (QGraphicsItem* item : collidingItems) {
      // Si el objeto colisionado es un QGraphicsRectItem (puedes cambiar según corresponda)
      if (dynamic_cast<QGraphicsPixmapItem*>(item)) {
          // qDebug() << "¡Colisión detectada!";
          this->setPos(rectPos); // Revertir la posición
          return;
      }
  }
  // qDebug() << "nada";
}

void pacman::keyReleaseEvent(QKeyEvent *event){
    keys[event->key()]=false;

}

void pacman::paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget) {
    QPixmap currentPixmap;
    switch (currentDirection) {
    case Qt::Key_W:
        currentPixmap = mouthOpen ? pacmanAup : pacmanBup;
        break;
    case Qt::Key_A:
        currentPixmap = mouthOpen ? pacmanAleft : pacmanBleft;
        break;
    case Qt::Key_S:
        currentPixmap = mouthOpen ? pacmanAdown : pacmanBdown;
        break;
    case Qt::Key_D:
    default:
        currentPixmap = mouthOpen ? pacmanA : pacmanB;
        break;
    }

    // Dibujar rectángulo base
    QGraphicsRectItem::paint(painter, option, widget);

    // Dibujar pixmap actual
    painter->drawPixmap(rect().toRect(), currentPixmap);

}


void pacman::makepac(QGraphicsScene *scena,pacman* pac){

    scena->addItem(pac);
     pac->setPos(222,380);
    scena->setFocusItem(pac);


}
