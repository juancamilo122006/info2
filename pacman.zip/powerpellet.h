#ifndef POWERPELLET_H
#define POWERPELLET_H

#include <QObject>
#include <QGraphicsRectItem>
#include <QPixmap>

#include <QPainter>
class powerpellet :public QObject, public QGraphicsRectItem
{
    Q_OBJECT
public:
    explicit powerpellet(const QRectF &rect, QGraphicsRectItem *parent = nullptr);
    static void addscene(QGraphicsScene *scena);
    void paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget) override;
    static bool isWallAt(int cellX, int cellY,  QGraphicsScene* scena);
    // static bool isPathCenter(int cellX, int cellY, QGraphicsPixmapItem* mapItem);
private:
    QPixmap power,fresas;
signals:
};

#endif // POWERPELLET_H
