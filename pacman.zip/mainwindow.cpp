#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QKeyEvent>
#include "wall.h"
#include "pacman.h"
#include "powerpellet.h"
#include <QGraphicsScene>     // Para la QGraphicsScene
#include <QResizeEvent>       // Para el QResizeEvent
#include <QObject>            // Para el sistema de señales y ranuras
#include "gosth.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    this->scena=new QGraphicsScene(this);
    this ->view=new QGraphicsView(this);

    //configuraciones view
    view->centerOn(0, 0);
    view->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view->setScene(scena);


    //configuracion scena
    scena->setBackgroundBrush(Qt::black);;
    // connect(this, &MainWindow::resizeEvent, [=](QResizeEvent*) {
    //     view->fitInView(scena->sceneRect(), Qt::KeepAspectRatio);
    // });
    //configuracion pacman

    QRectF pc(222,380, 24, 24);

    pacman* pac=new pacman(pc);

    // pac->setPos(222,380);

    pac->makepac(scena,pac);

    qDebug()<<pac->x()<<pac->y();
    //muros

     wall* pared=new wall(1,10,160);
    pared->makewalls(scena,pac);


    //fresas
    // powerpellet::addscene(scena);
    int x=170,y=230;
    int size=20;
    QRectF Gosth(x+20, y, size, size);
    QRectF Gosth1(x+20, y+20, size, size);
    QRectF Gosth2(x+20, y+20, size, size);
    QRectF Gosth3(x+20, y+20, size, size);
    gosth* gosthazul = new gosth(1,pac,Gosth);
    gosth* gosthrojo = new gosth(2,pac,Gosth1);
    gosth* gosthyellow = new gosth(3,pac,Gosth2);
    gosth* gosthpink = new gosth(4,pac,Gosth3);
    scena->addItem(gosthazul);
    scena->addItem(gosthrojo);
    scena->addItem(gosthyellow);
    scena->addItem(gosthpink);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow:: keyPressEvent(QKeyEvent *event){
    pac->keyPressEvent(event);
}

void MainWindow:: keyReleaseEvent(QKeyEvent *event){
    pac->keyReleaseEvent(event);
}


void MainWindow::resizeEvent(QResizeEvent* event) {
    QMainWindow::resizeEvent(event);
    view->resize(this->size());
    scena->setSceneRect(view->rect());
}
